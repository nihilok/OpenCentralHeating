from .central_heating import HeatingSystem
from .endpoints import router
